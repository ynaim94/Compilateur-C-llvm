int f(){

  return 1;
}

char f(){
  return 'a';
}
