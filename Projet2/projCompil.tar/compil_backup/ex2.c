int main() {
  int i,x;
  x=0;
  while (x<1000) {
    x += i;
    i++;
  }
  return x;
}
